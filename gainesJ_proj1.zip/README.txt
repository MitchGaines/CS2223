Jonathan Gaines
CS2223 - Algorithms
Project 1

To run:
- nagivate to root directory of project
- type "python3 proj1.py" and hit <Enter>
- next you may choose a set size by entering "1", "2", or
  "3" for a small, medium, or large set
- after each given set is run, you will receive this same
  prompt again; type "-1" to quit the program